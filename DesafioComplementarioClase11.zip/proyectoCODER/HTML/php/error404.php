<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/estilos.css">
    <title>ERROR 404 | GG_Culture</title>
</head>
<body style="color: black;">
    <div class="div--404">
        <div>
            <h1 class="div--404--tittle">ERROR:404</h1>
        </div>
        <p>
            Lo sentimos esta pagina no se encuentra disponible en estos momentos, por favor intente volver al principio. 
            <br>
            clickea en la imagen !
         </p>
        <div class="div--404--divimg">
            <a href="index.html"> <img class="div--404--img" src="../imagenes/logoGG.png" alt="logoGGCULTURE"> </a> 
        </div>
    </div>
</body>
</html>